"""
Лабораторная работа: Шаблоны проектирования
Реализация трех шаблонов для банковской системы:
1. Фабричный метод (порождающий)
2. Адаптер (структурный)
3. Стратегия (поведенческий)
"""

from abc import ABC, abstractmethod
from typing import Protocol


# ==================== БАЗОВЫЕ КЛАССЫ ====================

class Transaction(ABC):
    """Абстрактный класс транзакции"""

    def __init__(self, amount: float, description: str):
        self.amount = amount
        self.description = description
        self._processed = False

    @abstractmethod
    def process(self) -> str:
        """Обработать транзакцию"""
        pass

    @property
    def processed(self) -> bool:
        return self._processed


class Account:
    """Класс банковского счета"""

    def __init__(self, account_number: str, balance: float = 0.0):
        self.account_number = account_number
        self._balance = balance
        self.transactions = []

    @property
    def balance(self) -> float:
        return self._balance

    def deposit(self, amount: float):
        """Пополнить счет"""
        self._balance += amount

    def withdraw(self, amount: float) -> bool:
        """Снять со счета"""
        if self._balance >= amount:
            self._balance -= amount
            return True
        return False

    def add_transaction(self, transaction: Transaction) -> str:
        """Добавить транзакцию"""
        result = transaction.process()
        self.transactions.append(transaction)
        return result


# ==================== 1. ФАБРИЧНЫЙ МЕТОД ====================

class TransactionFactory(ABC):
    """Абстрактная фабрика транзакций"""

    @abstractmethod
    def create_transaction(self, amount: float, description: str) -> Transaction:
        pass


class DepositTransactionFactory(TransactionFactory):
    """Фабрика депозитных транзакций"""

    def create_transaction(self, amount: float, description: str) -> Transaction:
        return DepositTransaction(amount, description)


class WithdrawalTransactionFactory(TransactionFactory):
    """Фабрика транзакций снятия"""

    def create_transaction(self, amount: float, description: str) -> Transaction:
        return WithdrawalTransaction(amount, description)


class TransferTransactionFactory(TransactionFactory):
    """Фабрика транзакций перевода"""

    def __init__(self, target_account: Account):
        self.target_account = target_account

    def create_transaction(self, amount: float, description: str) -> Transaction:
        return TransferTransaction(amount, description, self.target_account)


# Конкретные реализации транзакций
class DepositTransaction(Transaction):
    def process(self) -> str:
        self._processed = True
        return f"✅ Депозит: {self.amount} руб. - {self.description}"


class WithdrawalTransaction(Transaction):
    def process(self) -> str:
        self._processed = True
        return f"💰 Снятие: {self.amount} руб. - {self.description}"


class TransferTransaction(Transaction):
    def __init__(self, amount: float, description: str, target_account: Account):
        super().__init__(amount, description)
        self.target_account = target_account

    def process(self) -> str:
        self._processed = True
        return f"🔄 Перевод: {self.amount} руб. -> {self.target_account.account_number} - {self.description}"


# ==================== 2. АДАПТЕР ====================

class LegacyBankSystem:
    """Старая банковская система (предполагаем, что не можем её менять)"""

    def make_deposit_legacy(self, acc_num: str, amt: float, desc: str) -> dict:
        return {"status": "success", "operation": "legacy_deposit", "amount": amt}

    def make_withdrawal_legacy(self, acc_num: str, amt: float, desc: str) -> dict:
        return {"status": "success", "operation": "legacy_withdrawal", "amount": amt}


class LegacyBankAdapter(Transaction):
    """Адаптер для совместимости со старой системой"""

    def __init__(self, legacy_system: LegacyBankSystem, account_number: str,
                 transaction_type: str, amount: float, description: str):
        super().__init__(amount, description)
        self.legacy_system = legacy_system
        self.account_number = account_number
        self.transaction_type = transaction_type

    def process(self) -> str:
        if self.transaction_type == "deposit":
            result = self.legacy_system.make_deposit_legacy(
                self.account_number, self.amount, self.description
            )
        elif self.transaction_type == "withdrawal":
            result = self.legacy_system.make_withdrawal_legacy(
                self.account_number, self.amount, self.description
            )
        else:
            raise ValueError("Неизвестный тип транзакции")

        self._processed = True
        return f"🔌 Legacy: {result['operation']} на {result['amount']} руб."


# ==================== 3. СТРАТЕГИЯ ====================

class FeeStrategy(Protocol):
    """Протокол стратегии комиссий"""

    def calculate_fee(self, amount: float) -> float: ...


class PercentageFeeStrategy:
    """Стратегия процентной комиссии"""

    def __init__(self, percentage: float):
        self.percentage = percentage

    def calculate_fee(self, amount: float) -> float:
        return amount * self.percentage / 100


class FixedFeeStrategy:
    """Стратегия фиксированной комиссии"""

    def __init__(self, fixed_amount: float):
        self.fixed_amount = fixed_amount

    def calculate_fee(self, amount: float) -> float:
        return self.fixed_amount


class NoFeeStrategy:
    """Стратегия без комиссии"""

    def calculate_fee(self, amount: float) -> float:
        return 0.0


class BankingService:
    """Банковский сервис, использующий стратегию"""

    def __init__(self, fee_strategy: FeeStrategy):
        self.fee_strategy = fee_strategy

    def set_fee_strategy(self, fee_strategy: FeeStrategy):
        """Установить новую стратегию комиссий"""
        self.fee_strategy = fee_strategy

    def apply_transaction_with_fee(self, transaction: Transaction) -> tuple[str, float]:
        """Применить транзакцию с комиссией"""
        fee = self.fee_strategy.calculate_fee(transaction.amount)
        result = transaction.process()
        return f"{result} (Комиссия: {fee:.2f} руб.)", fee


# ==================== ТЕСТЫ ====================

import unittest
from unittest.mock import Mock


class TestBankingPatterns(unittest.TestCase):
    """Тесты для шаблонов проектирования"""

    def setUp(self):
        """Настройка перед каждым тестом"""
        self.account = Account("TEST123", 1000.0)
        self.target_account = Account("TARGET456", 500.0)

    def test_factory_method(self):
        """Тест фабричного метода"""
        # Тест фабрики депозитов
        deposit_factory = DepositTransactionFactory()
        deposit = deposit_factory.create_transaction(100.0, "Тест депозит")
        self.assertIsInstance(deposit, DepositTransaction)
        self.assertEqual(deposit.amount, 100.0)

        # Тест фабрики переводов
        transfer_factory = TransferTransactionFactory(self.target_account)
        transfer = transfer_factory.create_transaction(200.0, "Тест перевода")
        self.assertIsInstance(transfer, TransferTransaction)
        self.assertEqual(transfer.target_account, self.target_account)

    def test_adapter_pattern(self):
        """Тест паттерна Адаптер"""
        legacy_system = LegacyBankSystem()
        adapter = LegacyBankAdapter(legacy_system, "ACC123", "deposit", 300.0, "Тест")

        result = adapter.process()
        self.assertTrue(adapter.processed)
        self.assertIn("Legacy", result)
        self.assertIn("300", result)

    def test_strategy_pattern(self):
        """Тест паттерна Стратегия"""
        # Тест процентной стратегии
        percentage_strategy = PercentageFeeStrategy(2.0)  # 2%
        self.assertEqual(percentage_strategy.calculate_fee(100.0), 2.0)

        # Тест фиксированной стратегии
        fixed_strategy = FixedFeeStrategy(10.0)
        self.assertEqual(fixed_strategy.calculate_fee(100.0), 10.0)

        # Тест банковского сервиса со стратегией
        service = BankingService(percentage_strategy)
        transaction = DepositTransaction(200.0, "Тест")
        result, fee = service.apply_transaction_with_fee(transaction)

        self.assertIn("Комиссия: 4.00", result)
        self.assertEqual(fee, 4.0)

    def test_mock_objects(self):
        """Тест с mock-объектами"""
        # Создаем mock-транзакцию
        mock_transaction = Mock(spec=Transaction)
        mock_transaction.amount = 100.0
        mock_transaction.description = "Mock транзакция"
        mock_transaction.process.return_value = "Mock результат"
        mock_transaction.processed = False

        # Используем mock в нашем коде
        result = self.account.add_transaction(mock_transaction)

        # Проверяем, что методы вызывались правильно
        mock_transaction.process.assert_called_once()
        self.assertEqual(result, "Mock результат")
        self.assertEqual(len(self.account.transactions), 1)


# ==================== ДЕМОНСТРАЦИЯ ====================

def demonstrate_patterns():
    """Демонстрация работы всех шаблонов"""
    print("=" * 60)
    print("ДЕМОНСТРАЦИЯ ШАБЛОНОВ ПРОЕКТИРОВАНИЯ")
    print("=" * 60)

    # Создаем счета
    main_account = Account("MAIN001", 5000.0)
    savings_account = Account("SAVINGS002", 2000.0)

    print(f"\n📊 Созданы счета:")
    print(f"Основной: {main_account.account_number} - {main_account.balance} руб.")
    print(f"Сберегательный: {savings_account.account_number} - {savings_account.balance} руб.")

    # 1. ДЕМОНСТРАЦИЯ ФАБРИЧНОГО МЕТОДА
    print(f"\n{'=' * 40}")
    print("1. ФАБРИЧНЫЙ МЕТОД")
    print(f"{'=' * 40}")

    # Создаем фабрики
    deposit_factory = DepositTransactionFactory()
    withdrawal_factory = WithdrawalTransactionFactory()
    transfer_factory = TransferTransactionFactory(savings_account)

    # Создаем транзакции через фабрики
    deposit = deposit_factory.create_transaction(1000.0, "Зарплата")
    withdrawal = withdrawal_factory.create_transaction(500.0, "Покупки")
    transfer = transfer_factory.create_transaction(300.0, "Накопления")

    # Выполняем транзакции
    print("Созданы транзакции через фабрики:")
    print(f"- {deposit.process()}")
    print(f"- {withdrawal.process()}")
    print(f"- {transfer.process()}")

    # 2. ДЕМОНСТРАЦИЯ АДАПТЕРА
    print(f"\n{'=' * 40}")
    print("2. АДАПТЕР")
    print(f"{'=' * 40}")

    legacy_system = LegacyBankSystem()
    legacy_adapter = LegacyBankAdapter(
        legacy_system, "LEGACY123", "deposit", 400.0, "Адаптерный платеж"
    )

    print("Работа со старой системой через адаптер:")
    print(f"- {legacy_adapter.process()}")

    # 3. ДЕМОНСТРАЦИЯ СТРАТЕГИИ
    print(f"\n{'=' * 40}")
    print("3. СТРАТЕГИЯ")
    print(f"{'=' * 40}")

    # Создаем стратегии комиссий
    standard_strategy = PercentageFeeStrategy(2.0)  # 2%
    premium_strategy = PercentageFeeStrategy(1.0)  # 1%
    fixed_strategy = FixedFeeStrategy(15.0)  # 15 руб.
    no_fee_strategy = NoFeeStrategy()  # 0%

    # Создаем банковские сервисы с разными стратегиями
    standard_service = BankingService(standard_strategy)
    premium_service = BankingService(premium_strategy)

    test_transaction = DepositTransaction(2000.0, "Крупный платеж")

    print("Расчет комиссий по разным стратегиям:")
    result1, fee1 = standard_service.apply_transaction_with_fee(test_transaction)
    print(f"- Стандарт (2%): {result1}")

    result2, fee2 = premium_service.apply_transaction_with_fee(test_transaction)
    print(f"- Премиум (1%): {result2}")

    # Меняем стратегию "на лету"
    premium_service.set_fee_strategy(fixed_strategy)
    result3, fee3 = premium_service.apply_transaction_with_fee(test_transaction)
    print(f"- Фиксированная: {result3}")

    premium_service.set_fee_strategy(no_fee_strategy)
    result4, fee4 = premium_service.apply_transaction_with_fee(test_transaction)
    print(f"- Без комиссии: {result4}")

    # 4. ИНТЕГРАЦИЯ ВСЕХ ШАБЛОНОВ
    print(f"\n{'=' * 40}")
    print("4. ИНТЕГРАЦИЯ ВСЕХ ШАБЛОНОВ")
    print(f"{'=' * 40}")

    # Создаем транзакцию через фабрику
    transaction_factory = DepositTransactionFactory()
    new_transaction = transaction_factory.create_transaction(1500.0, "Интеграционный тест")

    # Обрабатываем через сервис со стратегией
    banking_service = BankingService(PercentageFeeStrategy(1.5))
    result, fee = banking_service.apply_transaction_with_fee(new_transaction)

    # Добавляем на счет
    main_account.add_transaction(new_transaction)
    main_account.deposit(1500.0 - fee)  # Учитываем комиссию

    print("Интеграция всех шаблонов:")
    print(f"- {result}")
    print(f"- Баланс основного счета: {main_account.balance} руб.")
    print(f"- Всего транзакций: {len(main_account.transactions)}")

    print(f"\n{'=' * 60}")
    print("ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА")
    print(f"{'=' * 60}")


def run_tests():
    """Запуск тестов"""
    print(f"\n{'=' * 40}")
    print("ЗАПУСК ТЕСТОВ")
    print(f"{'=' * 40}")

    # Создаем test suite и запускаем
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestBankingPatterns)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print(f"\nТестов пройдено: {result.testsRun}")
    print(f"Ошибок: {len(result.errors)}")
    print(f"Провалов: {len(result.failures)}")


if __name__ == "__main__":
    # Демонстрация работы
    demonstrate_patterns()

    # Запуск тестов
    run_tests()