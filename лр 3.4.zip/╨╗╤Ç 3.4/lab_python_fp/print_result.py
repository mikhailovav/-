import functools

def print_result(func):
    """
    Декоратор, который печатает имя функции и форматированный результат
    её выполнения.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # 1. Вызов декорируемой функции
        result = func(*args, **kwargs)

        # 2. Печать имени функции
        print(func.__name__)

        # 3. Форматированный вывод результата
        if isinstance(result, list):
            # Если результат - список, выводим элементы в столбик
            for item in result:
                print(item)
        elif isinstance(result, dict):
            # Если результат - словарь, выводим ключи и значения через '=' в столбик
            for key, value in result.items():
                print(f"{key} = {value}")
        else:
            # Для всех остальных типов (int, str и т.д.) - обычный вывод
            print(result)

        # 4. Возврат результата
        return result

    return wrapper

# --- Шаблон реализации с использованием декоратора ---

@print_result
def test_1():
    return 1


@print_result
def test_2():
    return 'iu5'


@print_result
def test_3():
    return {'a': 1, 'b': 2}


@print_result
def test_4():
    return [1, 2]


if __name__ == '__main__':
    print('!!!!!!!!')
    # Результат вызова каждой функции будет выводиться декоратором
    test_1()
    test_2()
    test_3()
    test_4()