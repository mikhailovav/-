import json
import sys
import time
import functools
import random
from time import sleep


# ========================================================================
# БЛОК ИНСТРУМЕНТОВ ИЗ ПРЕДЫДУЩИХ ЗАДАЧ
# ========================================================================

# Реализация cm_timer_1 (Задача 6)
class cm_timer_1:
    """Контекстный менеджер для измерения времени, реализованный через класс."""

    def __enter__(self):
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = time.time()
        execution_time = end_time - self.start_time
        print(f"time: {execution_time:.3f}")
        return False  # Позволяем исключениям распространяться


# Реализация print_result (Задача 5)
def print_result(func):
    """Декоратор, который печатает имя функции и форматированный результат."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        print(func.__name__)

        if isinstance(result, list):
            for item in result:
                print(item)
        elif isinstance(result, dict):
            for key, value in result.items():
                print(f"{key} = {value}")
        else:
            print(result)

        return result

    return wrapper


# ========================================================================
# ЗАГРУЗКА ДАННЫХ
# ========================================================================

# Получение пути к файлу из аргументов командной строки
path = None
if len(sys.argv) > 1:
    path = sys.argv[1]

# Загрузка данных
data = []
if path:
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Ошибка: Файл по пути '{path}' не найден.")
        sys.exit(1)
else:
    # Пример данных для тестирования, если файл не передан или недоступен
    print("ВНИМАНИЕ: Путь к файлу не был передан. Используются тестовые данные.")
    data = [
        {"job_title": "Программист Python", "salary": 150000},
        {"job_title": "АНАЛИТИК", "salary": 120000},
        {"job_title": "Программист C#", "salary": 160000},
        {"job_title": "программист java", "salary": 140000},
        {"job_title": "Менеджер Продаж", "salary": 80000},
        {"job_title": "Программист C#", "salary": 165000},
        {"job_title": "программист PYTHON", "salary": 155000},
        {"job_title": "тестировщик", "salary": 110000},
    ]


# ========================================================================
# РЕАЛИЗАЦИЯ ФУНКЦИЙ f1, f2, f3, f4
# ========================================================================

@print_result
def f1(arg: list) -> list:
    """
    Получает уникальные, регистронезависимо отсортированные профессии.
    (1 строка)
    """
    # Используем словарь для регистронезависимой уникальности:
    # ключ - lower(), значение - оригинальная строка.
    # Затем сортируем значения (оригинальные строки) регистронезависимо.
    return sorted(list({item['job_title'].lower(): item['job_title'] for item in arg}.values()), key=str.lower)


@print_result
def f2(arg: list) -> list:
    """
    Фильтрует профессии, оставляя только те, что начинаются со слова "программист".
    (1 строка)
    """
    # Фильтруем, используя регистронезависимую проверку startswith
    return list(filter(lambda x: x.lower().startswith('программист'), arg))


@print_result
def f3(arg: list) -> list:
    """
    Модифицирует каждую специальность, добавляя ", с опытом Python".
    (1 строка)
    """
    # Используем map для модификации каждой строки
    return list(map(lambda x: f"{x}, с опытом Python", arg))


@print_result
def f4(arg: list) -> list:
    """
    Генерирует зарплату (100k-200k) для каждой специальности и присоединяет ее.
    (До 3 строк)
    """
    # 1. Генерируем список случайных зарплат
    salaries = [random.randint(100000, 200000) for _ in range(len(arg))]
    # 2. Объединяем специальности и зарплаты и форматируем строку
    result = [f"{job}, зарплата {salary} руб." for job, salary in zip(arg, salaries)]
    return result


# ========================================================================
# ОСНОВНОЙ БЛОК ВЫПОЛНЕНИЯ
# ========================================================================

if __name__ == '__main__':
    # Измеряем время работы всей цепочки функций
    with cm_timer_1():
        # Цепочка вызовов функций: f1 -> f2 -> f3 -> f4
        f4(f3(f2(f1(data))))