# lab_python_fp/field.py

def field(items, *args):
    """
    Генератор, последовательно выдающий значения ключей словаря.
    Поддерживает извлечение одного значения или под-словаря.
    Пропускает элементы, содержащие None.
    """
    assert len(args) > 0

    # 1. Извлечение одного поля
    if len(args) == 1:
        key = args[0]
        for item in items:
            # Используем get() для безопасного доступа.
            # item.get(key) возвращает None, если ключ отсутствует или значение None.
            value = item.get(key)
            if value is not None:
                yield value

    # 2. Извлечение нескольких полей (формирование под-словаря)
    else:
        for item in items:
            sub_dict = {}
            for key in args:
                value = item.get(key)
                if value is not None:
                    # Добавляем в sub_dict только, если значение не None
                    sub_dict[key] = value

            # Если sub_dict не пустой (т.е. содержит хотя бы одно поле без None), выдаем его
            if sub_dict:
                yield sub_dict


# --- Тестовый пример для экрана ---
if __name__ == '__main__':
    goods = [
        {'title': 'Ковер', 'price': 2000, 'color': 'green', 'weight': None},
        {'title': 'Диван для отдыха', 'price': 5300, 'color': 'black', 'weight': 100},
        {'title': 'Кресло', 'price': None, 'color': 'red', 'weight': 50},
        {'title': 'Стол', 'price': None, 'color': None, 'weight': None},
    ]

    print("--- 1. field(goods, 'title') (Одно поле) ---")
    for title in field(goods, 'title'):
        print(title)

    print("\n--- 2. field(goods, 'title', 'price') (Несколько полей) ---")
    for item_dict in field(goods, 'title', 'price'):
        print(item_dict)

    print("\n--- 3. field(goods, 'title', 'weight', 'color') (Пропуск None) ---")
    for item_dict in field(goods, 'title', 'weight', 'color'):
        print(item_dict)

    print("\n--- 4. field(goods, 'weight', 'size') (Пропуск всего словаря 'Стол') ---")
    for item_dict in field(goods, 'weight', 'size'):
        print(item_dict)
