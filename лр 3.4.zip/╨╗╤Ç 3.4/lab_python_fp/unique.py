# lab_python_fp/unique.py

class Unique(object):
    """
    Итератор для удаления дубликатов из любого итерируемого объекта.
    Корректно работает с генераторами и поддерживает игнорирование регистра.
    """

    def __init__(self, items, **kwargs):
        # Сохраняем исходный итерируемый объект, а не итератор от него.
        # Это позволяет, например, повторно использовать список.
        self._items = items

        # Множество для хранения уже встреченных элементов/форм (canonical form)
        self._seen = set()

        # Извлекаем именованный аргумент ignore_case, по умолчанию False
        self._ignore_case = kwargs.get('ignore_case', False)

        # Создаем итератор из исходных данных
        self._iterator = iter(self._items)

    def __next__(self):
        while True:
            try:
                # 1. Получаем следующий элемент из исходного итератора
                current_item = next(self._iterator)
            except StopIteration:
                # Если исходный итератор закончился, останавливаем наш итератор
                raise StopIteration

            # 2. Определяем каноническую форму для проверки дубликатов
            # Каноническая форма - это то, что мы помещаем в множество _seen
            check_item = current_item

            # Если это строка и включено игнорирование регистра, используем нижний регистр
            if self._ignore_case and isinstance(current_item, str):
                check_item = current_item.lower()

            # 3. Проверяем, встречали ли мы этот элемент
            if check_item not in self._seen:
                self._seen.add(check_item)
                # Возвращаем исходный элемент, не модифицированный
                return current_item

            # Если элемент уже был, цикл продолжает работу, вызывая next(self._iterator)

    def __iter__(self):
        # Метод __iter__ должен возвращать сам объект, чтобы класс был итератором
        return self


# --- Тестовый пример для экрана ---
if __name__ == '__main__':
    import random


    # Предполагаем, что gen_random доступен или вставлен здесь
    def gen_random(num_count, begin, end):
        for _ in range(num_count):
            yield random.randint(begin, end)


    # 1. Тест с генератором (Проверка на корректную работу с одноразовыми источниками)
    random.seed(10)
    data_gen = gen_random(15, 1, 5)
    print("--- 1. Unique(gen_random) ---")
    print(f"Результат: {list(Unique(data_gen))}")

    # 2. Тест со строками (Без ignore_case)
    data_str_case = ['a', 'A', 'b', 'B', 'a', 'A', 'b', 'B', 'c']
    print("\n--- 2. Unique(data_str) (Case Sensitive) ---")
    print(f"Результат: {list(Unique(data_str_case))}")

    # 3. Тест со строками (С ignore_case=True)
    print("\n--- 3. Unique(data_str, ignore_case=True) ---")
    print(f"Результат: {list(Unique(data_str_case, ignore_case=True))}")

    # 4. Тест со списком чисел (Корректное удаление)
    data_int = [1, 1, 1, 2, 2, 2, 3, 3, 4]
    print("\n--- 4. Unique(data_int) ---")
    print(f"Результат: {list(Unique(data_int))}")