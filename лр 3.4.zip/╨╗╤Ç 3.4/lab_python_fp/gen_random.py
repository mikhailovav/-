# lab_python_fp/gen_random.py

import random


def gen_random(num_count, begin, end):
    """
    Генератор, который последовательно выдает заданное количество
    случайных чисел в заданном диапазоне.
    """
    for _ in range(num_count):
        # random.randint(a, b) возвращает случайное целое число N такое,
        # что a <= N <= b.
        yield random.randint(begin, end)


# --- Тестовый пример для экрана ---
if __name__ == '__main__':
    # Установим seed для воспроизводимости результата при тестировании
    random.seed(42)

    # 5 случайных чисел в диапазоне от 1 до 3
    print("--- gen_random(5, 1, 3) ---")
    random_numbers = list(gen_random(5, 1, 3))
    print(random_numbers)

    # 8 случайных чисел в диапазоне от 10 до 20
    print("\n--- gen_random(8, 10, 20) ---")
    random_numbers_large = list(gen_random(8, 10, 20))
    print(random_numbers_large)