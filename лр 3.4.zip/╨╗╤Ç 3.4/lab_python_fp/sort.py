def sort_key_abs(item):
    """Функция, возвращающая модуль числа для использования в качестве ключа сортировки."""
    return abs(item)

data = [4, -30, 30, 100, -100, 123, 1, 0, -1, -4]

if __name__ == '__main__':
    # 1. Без использования lambda-функции
    # Используем функцию sort_key_abs в качестве ключа (key)
    # reverse=True для сортировки по убыванию
    result = sorted(data, key=sort_key_abs, reverse=True)
    print(result)

    # 2. С использованием lambda-функции
    # Используем анонимную lambda-функцию key=lambda x: abs(x)
    result_with_lambda = sorted(data, key=lambda x: abs(x), reverse=True)
    print(result_with_lambda)