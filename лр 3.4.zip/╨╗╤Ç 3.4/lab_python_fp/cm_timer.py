import time
from time import sleep
from contextlib import contextmanager
import functools


# --- 1. Реализация на основе класса (cm_timer_1) ---

class cm_timer_1:
    """
    Контекстный менеджер для измерения времени, реализованный через класс
    с методами __enter__ и __exit__.
    """

    def __enter__(self):
        # Запоминаем время на входе в блок 'with'
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Вычисляем и печатаем время на выходе из блока
        end_time = time.time()
        execution_time = end_time - self.start_time
        # Ограничиваем вывод тремя знаками после запятой
        print(f"time: {execution_time:.3f}")
        # Возвращаем False, чтобы любые исключения внутри блока обрабатывались стандартно
        return False


# --- 2. Реализация с использованием contextlib (cm_timer_2) ---

@contextmanager
def cm_timer_2():
    """
    Контекстный менеджер для измерения времени, реализованный с помощью
    декоратора @contextmanager и генератора.
    """

    start_time = time.time()
    try:
        # Код до yield выполняется при входе в блок 'with'
        yield
    finally:
        # Код в блоке finally выполняется при выходе из блока 'with'
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"time: {execution_time:.3f}")


# --- Тестирование (как в примере задачи) ---

if __name__ == '__main__':
    print("--- Тест cm_timer_1 (примерно 2 секунды) ---")
    with cm_timer_1():
        sleep(2.0)

    print("\n--- Тест cm_timer_2 (примерно 0.5 секунды) ---")
    with cm_timer_2():
        sleep(0.5)